importScripts('/_nuxt/workbox.42554690.js', 'custom-sw.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/app.418e460f2f8fe6a0a83c.js",
    "revision": "68a686e49c43c7fb4c186f4803e6e656"
  },
  {
    "url": "/_nuxt/layouts/default.27bb440b70c907cac70a.js",
    "revision": "2d62b74c01baae214094417139896889"
  },
  {
    "url": "/_nuxt/manifest.55f00a34747a61b2ae29.js",
    "revision": "be622bb19dee3de11c5063b2e75d286f"
  },
  {
    "url": "/_nuxt/pages/_id/index.a1c49e1658afbef9ddea.js",
    "revision": "84593eab45cacc5bf193d4222e4f453f"
  },
  {
    "url": "/_nuxt/pages/about/index.45b01b8487d948562431.js",
    "revision": "6dcefc386b18a2d62e11bf4d588ee27d"
  },
  {
    "url": "/_nuxt/pages/articles/_id/index.95aa567be33154bf856c.js",
    "revision": "5fd929c24e69018d925b810f96a74907"
  },
  {
    "url": "/_nuxt/pages/index.f66400814ace7f5a482d.js",
    "revision": "411af57d36f8030d53a575cfcf600ab9"
  },
  {
    "url": "/_nuxt/vendor.d5f38d6a475cd4f1fde9.js",
    "revision": "6c3746cc144b6502845ee230b4b27d91"
  }
], {
  "cacheId": "lite-blog",
  "directoryIndex": "/",
  "cleanUrls": false
})



workbox.clientsClaim()
workbox.skipWaiting()


workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')





